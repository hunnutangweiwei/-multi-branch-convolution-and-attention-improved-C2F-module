import torch
import torch.nn as nn
from timm.models.layers import DropPath
from ultralytics.nn.modules.block import *
class ChannelAttention(nn.Module):
    """通道注意力模块（SE Block）"""
    def __init__(self, channel, reduction=16):
        super(ChannelAttention, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)
        self.fc = nn.Sequential(
            nn.Linear(channel, channel // reduction, bias=False),
            nn.ReLU(inplace=True),
            nn.Linear(channel // reduction, channel, bias=False)
        )
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        b, c, _, _ = x.size()
        avg_out = self.fc(self.avg_pool(x).view(b, c))
        max_out = self.fc(self.max_pool(x).view(b, c))
        out = avg_out + max_out
        return self.sigmoid(out).view(b, c, 1, 1)


class SpatialAttention(nn.Module):
    """空间注意力模块"""
    def __init__(self, kernel_size=7):
        super(SpatialAttention, self).__init__()
        self.conv = nn.Conv2d(2, 1, kernel_size=kernel_size, padding=kernel_size // 2, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = torch.mean(x, dim=1, keepdim=True)
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        out = torch.cat([avg_out, max_out], dim=1)
        out = self.conv(out)
        return self.sigmoid(out)


class AttenMAP(nn.Module):
    """AttenMAP 模块"""
    def __init__(self, in_channels, out_channels, map_reduce=8):
        super(AttenMAP, self).__init__()
        inter_channels = in_channels // map_reduce

        # 多分支卷积
        self.branch1 = nn.Sequential(
            nn.Conv2d(in_channels, inter_channels, kernel_size=1, stride=1, padding=0),
            nn.Conv2d(inter_channels, inter_channels, kernel_size=3, stride=1, padding=1)
        )
        self.branch2 = nn.Sequential(
            nn.Conv2d(in_channels, inter_channels, kernel_size=1, stride=1, padding=0),
            nn.Conv2d(inter_channels, inter_channels, kernel_size=3, stride=1, padding=2, dilation=2)
        )
        self.branch3 = nn.Sequential(
            nn.Conv2d(in_channels, inter_channels, kernel_size=1, stride=1, padding=0),
            nn.Conv2d(inter_channels, inter_channels, kernel_size=3, stride=1, padding=3, dilation=3)
        )

        # 注意力模块
        self.channel_attention = ChannelAttention(inter_channels * 3)
        self.spatial_attention = SpatialAttention()

        # 特征融合
        self.conv_fusion = nn.Conv2d(inter_channels * 3, out_channels, kernel_size=1, stride=1, padding=0)

        # 残差连接
        self.shortcut = nn.Conv2d(in_channels, out_channels, kernel_size=1, stride=1, padding=0)

    def forward(self, x):
        # 多分支特征提取
        x1 = self.branch1(x)
        x2 = self.branch2(x)
        x3 = self.branch3(x)

        # 特征拼接
        out = torch.cat([x1, x2, x3], dim=1)

        # 通道注意力
        channel_att = self.channel_attention(out)
        out = out * channel_att

        # 空间注意力
        spatial_att = self.spatial_attention(out)
        out = out * spatial_att

        # 特征融合
        out = self.conv_fusion(out)

        # 残差连接
        shortcut = self.shortcut(x)
        out = out + shortcut

        return out


class FasterBlockWithAttenMAP(nn.Module):
    """改进后的 FasterBlock，集成了 AttenMAP 模块"""
    def __init__(self, inc, dim, n_div=4, mlp_ratio=2, drop_path=0.1, layer_scale_init_value=0.0, pconv_fw_type='split_cat'):
        super(FasterBlockWithAttenMAP, self).__init__()
        self.dim = dim
        self.mlp_ratio = mlp_ratio
        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()
        self.n_div = n_div

        # MLP 层
        mlp_hidden_dim = int(dim * mlp_ratio)
        self.mlp = nn.Sequential(
            nn.Conv2d(dim, mlp_hidden_dim, kernel_size=1, stride=1, padding=0),
            nn.Conv2d(mlp_hidden_dim, dim, kernel_size=1, stride=1, padding=0, bias=False)
        )

        # AttenMAP 模块
        self.attenmap = AttenMAP(dim, dim)

        # 通道调整
        self.adjust_channel = None
        if inc != dim:
            self.adjust_channel = nn.Conv2d(inc, dim, kernel_size=1, stride=1, padding=0)

        # 层缩放
        if layer_scale_init_value > 0:
            self.layer_scale = nn.Parameter(layer_scale_init_value * torch.ones((dim)), requires_grad=True)
            self.forward = self.forward_layer_scale
        else:
            self.forward = self.forward_plain

    def forward_plain(self, x):
        if self.adjust_channel is not None:
            x = self.adjust_channel(x)
        shortcut = x
        x = self.attenmap(x)  # 使用 AttenMAP 模块
        x = shortcut + self.drop_path(self.mlp(x))
        return x

    def forward_layer_scale(self, x):
        if self.adjust_channel is not None:
            x = self.adjust_channel(x)
        shortcut = x
        x = self.attenmap(x)  # 使用 AttenMAP 模块
        x = shortcut + self.drop_path(
            self.layer_scale.unsqueeze(-1).unsqueeze(-1) * self.mlp(x))
        return x

class C2f_Faster_AttenMAP(C2f):
    def __init__(self, c1, c2, n=1, shortcut=False, g=1, e=0.5):
        super().__init__(c1, c2, n, shortcut, g, e)
        self.m = nn.ModuleList(FasterBlockWithAttenMAP(self.c, self.c) for _ in range(n))