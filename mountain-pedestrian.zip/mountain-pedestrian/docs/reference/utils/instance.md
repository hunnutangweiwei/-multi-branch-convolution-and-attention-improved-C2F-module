---
description: Dive into Ultralytics detailed utility guide. Learn about Bboxes, _ntuple and more from Ultralytics utils.instance module.
keywords: Ultralytics, Bboxes, _ntuple, utility, ultralytics utils.instance
---

## Bboxes
---
### ::: ultralytics.utils.instance.Bboxes
<br><br>

## Instances
---
### ::: ultralytics.utils.instance.Instances
<br><br>

## _ntuple
---
### ::: ultralytics.utils.instance._ntuple
<br><br>