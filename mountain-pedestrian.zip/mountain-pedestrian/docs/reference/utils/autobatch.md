---
description: Explore Ultralytics documentation for check_train_batch_size utility in the autobatch module. Understand how it could improve your machine learning process.
keywords: Ultralytics, check_train_batch_size, autobatch, utility, machine learning, documentation
---

## check_train_batch_size
---
### ::: ultralytics.utils.autobatch.check_train_batch_size
<br><br>

## autobatch
---
### ::: ultralytics.utils.autobatch.autobatch
<br><br>