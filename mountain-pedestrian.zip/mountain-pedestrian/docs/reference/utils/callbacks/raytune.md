---
description: Discover the functionality of the on_fit_epoch_end callback in the Ultralytics YOLO framework. Learn how to end an epoch in your deep learning projects.
keywords: Ultralytics, YOLO, on_fit_epoch_end, callbacks, documentation, deep learning, YOLO framework
---

## on_fit_epoch_end
---
### ::: ultralytics.utils.callbacks.raytune.on_fit_epoch_end
<br><br>