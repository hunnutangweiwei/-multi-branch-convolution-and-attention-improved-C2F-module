---
description: Explore Ultralytics documentation on prediction function starters & register trackers. Understand our code & its applications better.
keywords: Ultralytics, YOLO, on predict start, register tracker, prediction functions, documentation
---

## on_predict_start
---
### ::: ultralytics.trackers.track.on_predict_start
<br><br>

## on_predict_postprocess_end
---
### ::: ultralytics.trackers.track.on_predict_postprocess_end
<br><br>

## register_tracker
---
### ::: ultralytics.trackers.track.register_tracker
<br><br>