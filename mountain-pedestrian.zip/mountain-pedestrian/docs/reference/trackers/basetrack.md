---
description: Get familiar with TrackState in Ultralytics. Learn how it is used in the BaseTrack of the Ultralytics tracker for enhanced functionality.
keywords: Ultralytics, TrackState, BaseTrack, Ultralytics tracker, Ultralytics documentation
---

## TrackState
---
### ::: ultralytics.trackers.basetrack.TrackState
<br><br>

## BaseTrack
---
### ::: ultralytics.trackers.basetrack.BaseTrack
<br><br>