---
description: Learn about the BaseTrainer class in the Ultralytics library. From training control, customization to advanced usage.
keywords: Ultralytics, BaseTrainer, Machine Learning, Training Control, Python library
---

## BaseTrainer
---
### ::: ultralytics.engine.trainer.BaseTrainer
<br><br>