---
description: Learn about Ultralytics BasePredictor, an essential component of our engine that serves as the foundation for all prediction operations.
keywords: Ultralytics, BasePredictor, YOLO, prediction, engine
---

## BasePredictor
---
### ::: ultralytics.engine.predictor.BasePredictor
<br><br>