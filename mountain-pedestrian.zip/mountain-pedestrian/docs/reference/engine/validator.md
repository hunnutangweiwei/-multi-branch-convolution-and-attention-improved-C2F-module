---
description: Learn about the Ultralytics BaseValidator module. Understand its principles, uses, and how it interacts with other components.
keywords: Ultralytics, BaseValidator, Ultralytics engine, module, components
---

## BaseValidator
---
### ::: ultralytics.engine.validator.BaseValidator
<br><br>