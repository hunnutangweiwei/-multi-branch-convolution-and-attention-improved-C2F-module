---
description: Explore the specifics of using the RTDETR model in Ultralytics. Detailed documentation layered with explanations and examples.
keywords: Ultralytics, RTDETR model, Ultralytics models, object detection, Ultralytics documentation
---

## RTDETR
---
### ::: ultralytics.models.rtdetr.model.RTDETR
<br><br>