---
description: Learn how to use the RTDETRPredictor model of the Ultralytics package. Detailed documentation, usage instructions, and advice.
keywords: Ultralytics, RTDETRPredictor, model documentation, guide, real-time object detection
---

## RTDETRPredictor
---
### ::: ultralytics.models.rtdetr.predict.RTDETRPredictor
<br><br>