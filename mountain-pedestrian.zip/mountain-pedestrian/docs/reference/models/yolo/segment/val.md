---
description: Get practical insights about our SegmentationValidator in YOLO Ultralytics models. Discover functionality details, methods, inputs, and outputs.
keywords: Ultralytics, YOLO, SegmentationValidator, model segmentation, image classification, object detection
---

## SegmentationValidator
---
### ::: ultralytics.models.yolo.segment.val.SegmentationValidator
<br><br>

## val
---
### ::: ultralytics.models.yolo.segment.val.val
<br><br>