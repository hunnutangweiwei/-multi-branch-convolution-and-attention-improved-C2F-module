---
description: Maximize your YOLO model's performance with our SegmentationTrainer. Explore comprehensive guides and tutorials on ultralytics.com.
keywords: Ultralytics, YOLO, SegmentationTrainer, image segmentation, object detection, model training, YOLO model
---

## SegmentationTrainer
---
### ::: ultralytics.models.yolo.segment.train.SegmentationTrainer
<br><br>

## train
---
### ::: ultralytics.models.yolo.segment.train.train
<br><br>