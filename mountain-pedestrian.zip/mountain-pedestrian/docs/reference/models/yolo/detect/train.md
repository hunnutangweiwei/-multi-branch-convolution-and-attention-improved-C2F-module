---
description: Maximize your model's potential with Ultralytics YOLO Detection Trainer. Learn advanced techniques, tips, and tricks for training.
keywords: Ultralytics YOLO, YOLO, Detection Trainer, Model Training, Machine Learning, Deep Learning, Computer Vision
---

## DetectionTrainer
---
### ::: ultralytics.models.yolo.detect.train.DetectionTrainer
<br><br>

## train
---
### ::: ultralytics.models.yolo.detect.train.train
<br><br>