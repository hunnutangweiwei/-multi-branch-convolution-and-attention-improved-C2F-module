---
description: Explore the PoseValidator—review how Ultralytics YOLO validates poses for object detection. Improve your understanding of YOLO.
keywords: PoseValidator, Ultralytics, YOLO, Object detection, Pose validation
---

## PoseValidator
---
### ::: ultralytics.models.yolo.pose.val.PoseValidator
<br><br>

## val
---
### ::: ultralytics.models.yolo.pose.val.val
<br><br>