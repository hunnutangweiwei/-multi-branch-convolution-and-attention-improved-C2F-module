---
description: Explore the Ultralytics ClassificationPredictor guide for model prediction and visualization. Build powerful AI models with YOLO.
keywords: Ultralytics, classification predictor, predict, YOLO, AI models, model visualization
---

## ClassificationPredictor
---
### ::: ultralytics.models.yolo.classify.predict.ClassificationPredictor
<br><br>

## predict
---
### ::: ultralytics.models.yolo.classify.predict.predict
<br><br>