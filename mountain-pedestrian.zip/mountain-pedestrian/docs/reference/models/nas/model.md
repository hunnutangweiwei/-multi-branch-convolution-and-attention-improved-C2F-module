---
description: Learn how our NAS model operates in Ultralytics. Comprehensive guide with detailed examples. Master the nuances of Ultralytics NAS model.
keywords: Ultralytics, NAS model, NAS guide, machine learning, model documentation
---

## NAS
---
### ::: ultralytics.models.nas.model.NAS
<br><br>