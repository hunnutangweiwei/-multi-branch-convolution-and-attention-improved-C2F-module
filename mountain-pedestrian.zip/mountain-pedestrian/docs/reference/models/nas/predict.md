---
description: Explore Ultralytics NASPredictor. Understand high-level architecture of the model for effective implementation and efficient predictions.
keywords: NASPredictor, Ultralytics, Ultralytics model, model architecture, efficient predictions
---

## NASPredictor
---
### ::: ultralytics.models.nas.predict.NASPredictor
<br><br>