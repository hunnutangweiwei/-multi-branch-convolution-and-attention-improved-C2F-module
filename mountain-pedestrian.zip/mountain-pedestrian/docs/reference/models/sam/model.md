---
description: Dive into the SAM model details in the Ultralytics YOLO documentation. Understand, implement, and optimize your model use.
keywords: Ultralytics, YOLO, SAM Model, Documentations, Machine Learning, AI, Convolutional neural network
---

## SAM
---
### ::: ultralytics.models.sam.model.SAM
<br><br>