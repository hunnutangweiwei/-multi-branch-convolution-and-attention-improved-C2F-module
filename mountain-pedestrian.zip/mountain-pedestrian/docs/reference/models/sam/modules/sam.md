---
description: Explore the Sam module of Ultralytics. Discover detailed methods, classes, and information for efficient deep-learning model training!.
keywords: Ultralytics, Sam module, deep learning, model training, Ultralytics documentation
---

## Sam
---
### ::: ultralytics.models.sam.modules.sam.Sam
<br><br>