---
description: Learn all about Ultralytics FastSAM model. Dive into our comprehensive guide for seamless integration and efficient model training.
keywords: Ultralytics, FastSAM model, Model documentation, Efficient model training
---

## FastSAM
---
### ::: ultralytics.models.fastsam.model.FastSAM
<br><br>