---
description: Enhance your machine learning model with Ultralytics’ auto_annotate function. Simplify data annotation for improved model training.
keywords: Ultralytics, Auto-Annotate, Machine Learning, AI, Annotation, Data Processing, Model Training
---

## auto_annotate
---
### ::: ultralytics.data.annotator.auto_annotate
<br><br>