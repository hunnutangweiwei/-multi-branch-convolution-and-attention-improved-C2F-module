---
description: Explore BaseDataset in Ultralytics docs. Learn how this implementation simplifies dataset creation and manipulation.
keywords: Ultralytics, docs, BaseDataset, data manipulation, dataset creation
---

## BaseDataset
---
### ::: ultralytics.data.base.BaseDataset
<br><br>