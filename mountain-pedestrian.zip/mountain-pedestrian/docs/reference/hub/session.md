---
description: Explore details about the HUBTrainingSession in Ultralytics framework. Learn to utilize this functionality for effective model training.
keywords: Ultralytics, HUBTrainingSession, Documentation, Model Training, AI, Machine Learning, YOLO
---

## HUBTrainingSession
---
### ::: ultralytics.hub.session.HUBTrainingSession
<br><br>